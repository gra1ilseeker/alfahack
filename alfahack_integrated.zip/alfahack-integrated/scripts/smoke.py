"""Exercise the running cabinet API with an isolated synthetic account."""
import argparse,json,uuid,urllib.request,urllib.error
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--base',default='http://127.0.0.1:8000');args=parser.parse_args()
base=args.base.rstrip('/');token=None

def call(path,payload=None):
    headers={'Content-Type':'application/json'}
    if token:headers['Authorization']='Bearer '+token
    request=urllib.request.Request(base+path,data=json.dumps(payload).encode() if payload is not None else None,headers=headers)
    try:
        with urllib.request.urlopen(request,timeout=60) as response:return json.load(response)
    except urllib.error.HTTPError as error:raise RuntimeError(error.read().decode()) from error

source=json.loads((Path(__file__).resolve().parents[1]/'backend/ml_bundle/example_request.json').read_text())['client']
email='smoke-'+uuid.uuid4().hex[:10]+'@example.com'
token=call('/auth/register',{'email':email,'password':uuid.uuid4().hex})['access_token']
profile=call('/profile/',{'industry':source['sector'],'employees':int(source['headcount']),'goals':'Synthetic smoke test',
    'credit_context':{'requested_amount':source['requested_amount'],'desired_term_months':int(source['desired_term_months']),
        'company_age_months':int(source['company_age_months']),'region':source['region'],'legal_form':source['legal_form'],
        'purpose':source['purpose'],'overdue_days':int(source['overdue_days']),'collateral_coverage':source['collateral_coverage'],
        'cash_balance':source['cash_last'],'debt_balance':source['debt_last'],'monthly_debt_payment':source['existing_payment']}})
reports=[dict(period=f'2026-{month:02d}',revenue=source['revenue_mean'],expenses=source['revenue_mean']-source['profit_mean'],cash_flow=source['profit_mean']) for month in range(4,10)]
call(f"/metrics/{profile['id']}",{'metrics':reports})
products=call('/products/')
request={'profile_id':profile['id'],'products':[p['id'] for p in products],'mode':'deep'}
cold=call('/rank/products',request)['result'];assert cold['recommendations']
call('/events/',{'profile_id':profile['id'],'event_type':'offer_selected','payload':{'product_id':cold['recommendations'][0]['product_id']}})
warm=call('/rank/products',request)['result']
assert warm['trace']['used_bert'] and warm['explanation']['completeness_ok']
print(json.dumps(dict(status='ok',catalog=len(products),model_version=warm['model_version'],
    top_offer=warm['recommendations'][0]['offer_id'],bert_used=warm['trace']['used_bert']),ensure_ascii=False,indent=2))
