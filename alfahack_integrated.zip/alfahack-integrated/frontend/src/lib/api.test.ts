import { test } from "node:test";
import assert from "node:assert/strict";
import { readRanking } from "./api.ts";
test("cascade recommendations preserve raw score and product mapping", () => {
  const rows = readRanking({ recommendations: [{ product_id: 7, offer_id: "x", ranking_score: .42, estimated_payment: 50000, note: "a" }] });
  assert.deepEqual(rows, [{ productId: 7, offerId: "x", score: .42, payment: 50000, note: "a" }]);
});
test("negative scores remain ranking scores", () => { assert.equal(readRanking({ recommendations: [{ product_id: 1, ranking_score: -2.5 }] })?.[0].score, -2.5); });
test("no offers is a valid empty response", () => { assert.deepEqual(readRanking({ status: "no_eligible_offers", recommendations: [] }), []); });
test("invalid scores are rejected rather than invented", () => { assert.deepEqual(readRanking({ recommendations: [{ product_id: 1, ranking_score: NaN }] }), []); });
