export type ApiConfig = { base: string; token: string | null };
export type CreditContext = {
  requested_amount: number; desired_term_months: number; company_age_months: number;
  region: string; legal_form: string; purpose: string; overdue_days: number;
  collateral_coverage: number; cash_balance: number; debt_balance: number; monthly_debt_payment: number;
};
export type MetricItem = {
  period: string; revenue: number; expenses: number; cash_flow: number; online_share?: number;
  cash_balance?: number | null; debt_balance?: number | null; monthly_debt_payment?: number | null;
};
export type ProfileResponse = { id: number; user_id: number; industry: string | null; revenue_band: string | null;
  employees: number | null; goals: string | null; credit_context: CreditContext | null };
export type ProfileCreate = { user_email?: string; industry: string; revenue_band?: string; employees: number;
  goals?: string; credit_context: CreditContext };
export type OfferMetadata = { offer_id?: string; lender_id?: string; term_months?: number; upfront_fee_rate?: number;
  collateral_required?: boolean; min_age_months?: number; purpose?: string; demo_catalog?: boolean };
export type ProductResponse = { id: number; name: string; type?: string | null; rate?: number | null;
  min_limit?: number | null; max_limit?: number | null; requirements_json?: OfferMetadata | null };
export type TokenResponse = { access_token: string; token_type?: string; expires_at?: string | null };
export type AccountResponse = { id: number; email: string; role: string; profile: Omit<ProfileResponse, "user_id"> | null };
export type DashboardResponse = { profile_id: number; summary: unknown; stability_index: number };
export type Attribution = { feature: string; label: string; contribution: number };
export type Explanation = { status: string; method?: string; first_offer_id?: string; reference_offer_id?: string;
  attributions?: Attribution[]; completeness_ok?: boolean };
export type RankingResult = { status: string; model_name?: string; model_version?: string; synthetic_catalog?: boolean;
  recommendations: Array<{ product_id: number; offer_id: string; ranking_score: number; note: string;
    estimated_payment: number; annual_rate: number; offer_term_months: number }>;
  explanation?: Explanation; history_event_count?: number; trace?: { path?: string; used_bert?: boolean };
  input_context?: { financial_months?: number; last_period?: string };
  exclusions?: Array<{ product_id: number; offer_id: string; reasons?: string[]; note?: string }> };
export type RankResponse = { ranking_id: number; result: RankingResult };
export type RankRow = { productId: number; offerId: string; score: number; note: string; payment: number | null };

export function defaultApiBase(): string { return (import.meta.env.VITE_API_BASE || "/api").replace(/\/$/, ""); }
function errorMessage(data: unknown, status: number): string {
  const detail = data && typeof data === "object" ? (data as { detail?: unknown }).detail : null;
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) return detail.map((x: { msg?: string; loc?: string[] }) => `${x.loc?.join(".") || ""}: ${x.msg || ""}`).join("; ");
  return `Ошибка ${status}`;
}
async function request<T>(config: ApiConfig, path: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers); headers.set("Accept", "application/json");
  if (init?.body != null) headers.set("Content-Type", "application/json");
  if (config.token) headers.set("Authorization", `Bearer ${config.token}`);
  let response: Response;
  try { response = await fetch(`${config.base.replace(/\/$/, "")}${path}`, { ...init, headers }); }
  catch { throw new Error("Нет связи с API. Проверьте, что бэкенд запущен."); }
  const data: unknown = await response.json().catch(() => null);
  if (!response.ok) throw new Error(errorMessage(data, response.status));
  return data as T;
}
const post = (body: unknown): RequestInit => ({ method: "POST", body: JSON.stringify(body) });
export const login = (c: ApiConfig, body: { email: string; password: string }) => request<TokenResponse>(c, "/auth/login", post(body));
export const register = (c: ApiConfig, body: { email: string; password: string }) => request<TokenResponse>(c, "/auth/register", post(body));
export const logout = (c: ApiConfig) => request(c, "/auth/logout", { method: "POST" });
export const getMe = (c: ApiConfig) => request<AccountResponse>(c, "/auth/me");
export const createProfile = (c: ApiConfig, body: ProfileCreate) => request<ProfileResponse>(c, "/profile/", post(body));
export const uploadMetrics = (c: ApiConfig, id: number, body: { metrics: MetricItem[] }) => request<{ count: number }>(c, `/metrics/${id}`, post(body));
export const getMetrics = (c: ApiConfig, id: number) => request<MetricItem[]>(c, `/metrics/${id}`);
export const getDashboard = (c: ApiConfig, id: number) => request<DashboardResponse>(c, `/dashboard/${id}`);
export const listProducts = (c: ApiConfig) => request<ProductResponse[]>(c, "/products/");
export const rankProducts = (c: ApiConfig, body: { profile_id: number; products: number[]; k?: number; explain?: boolean; mode?: string }) => request<RankResponse>(c, "/rank/products", post(body));
export const createEvent = (c: ApiConfig, body: { profile_id?: number | null; event_type: string; payload?: unknown }) => request<{ id: number }>(c, "/events/", post(body));
export const getImportance = (c: ApiConfig) => request<{ model_name: string; features: Array<{ feature: string; label: string; mean_ndcg_drop: number }> }>(c, "/ml/feature-importance");
export function rub(value: number): string { return new Intl.NumberFormat("ru-RU", { style: "currency", currency: "RUB", maximumFractionDigits: 0 }).format(value); }
export function readSummary(summary: unknown): string {
  if (typeof summary === "string") return summary;
  if (!summary || typeof summary !== "object") return "";
  const s = summary as Record<string, number>;
  return `Выручка ${rub(s.revenue || 0)}, расходы ${rub(s.expenses || 0)}, маржа ${Math.round((s.margin || 0) * 100)}%.`;
}
export function readRanking(result: unknown): RankRow[] | null {
  if (!result || typeof result !== "object") return null;
  const r = result as Record<string, unknown>;
  const items = Array.isArray(result) ? result : r.recommendations ?? r.result;
  if (!Array.isArray(items)) return null;
  return items.flatMap((item: Record<string, unknown>) => {
    const id = item.product_id ?? item.productId;
    const score = item.ranking_score ?? item.score;
    if (typeof id !== "number" || typeof score !== "number" || !Number.isFinite(score)) return [];
    return [{ productId: id, offerId: String(item.offer_id ?? ""), score,
      note: typeof item.note === "string" ? item.note : "",
      payment: typeof item.estimated_payment === "number" ? item.estimated_payment : null }];
  });
}
export function requirementFacts(value: unknown): Array<{ label: string; value: string }> {
  if (!value || typeof value !== "object") return [];
  const r = value as OfferMetadata;
  return [
    { label: "Срок", value: r.term_months ? `${r.term_months} мес.` : "—" },
    { label: "Разовая комиссия", value: r.upfront_fee_rate != null ? `${(r.upfront_fee_rate * 100).toFixed(1)}%` : "—" },
    { label: "Обеспечение", value: r.collateral_required ? "Требуется" : "Не требуется" },
    { label: "Возраст бизнеса от", value: r.min_age_months != null ? `${r.min_age_months} мес.` : "—" },
  ];
}
