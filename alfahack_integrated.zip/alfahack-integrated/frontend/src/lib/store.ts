import { create } from "zustand";
import { persist } from "zustand/middleware";
import { defaultApiBase, type ApiConfig, type MetricItem, type ProfileResponse } from "@/lib/api";
type CabinetState = {
  token: string | null; email: string | null; profile: ProfileResponse | null; metrics: MetricItem[] | null;
  setSession: (session: { token: string; email: string }) => void;
  setProfile: (profile: ProfileResponse) => void; setMetrics: (metrics: MetricItem[]) => void; reset: () => void;
};
export const useCabinet = create<CabinetState>()(persist((set) => ({
  token: null, email: null, profile: null, metrics: null,
  setSession: ({ token, email }) => set((state) => ({ token, email,
    profile: state.email === email ? state.profile : null, metrics: state.email === email ? state.metrics : null })),
  setProfile: (profile) => set({ profile }), setMetrics: (metrics) => set({ metrics }),
  reset: () => set({ token: null, email: null, profile: null, metrics: null }),
}), { name: "vektor-cabinet", partialize: (state) => ({ token: state.token, email: state.email, profile: state.profile, metrics: state.metrics }) }));
export function useApiConfig(): ApiConfig { return { base: defaultApiBase(), token: useCabinet((s) => s.token) }; }
