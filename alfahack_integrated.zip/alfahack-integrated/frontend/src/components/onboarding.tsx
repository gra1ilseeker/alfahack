import { useState } from "react";
import { createProfile, getMe, getMetrics, login, register, uploadMetrics, type MetricItem, type CreditContext } from "@/lib/api";
import { useApiConfig, useCabinet } from "@/lib/store";
const INDUSTRIES = [["retail", "Розничная торговля"], ["services", "Услуги и общепит"], ["it", "IT"], ["manufacturing", "Производство"], ["logistics", "Логистика"]];
const REGIONS = [["central", "Центральный"], ["north_west", "Северо-Запад"], ["south", "Юг"], ["volga", "Поволжье"], ["ural", "Урал"], ["siberia", "Сибирь"]];
const GOALS = [["working_capital", "Оборотные средства"], ["cash_gap", "Кассовый разрыв"], ["equipment", "Оборудование"]];
export function Onboarding() {
  const token = useCabinet((s) => s.token); const profile = useCabinet((s) => s.profile);
  if (!token) return <AuthStep />;
  if (!profile?.credit_context) return <ProfileStep />;
  return <MetricsStep />;
}
function AuthStep() {
  const config = useApiConfig(); const setSession = useCabinet((s) => s.setSession);
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(kind: "login" | "register") {
    setBusy(true); setError("");
    try {
      const body = { email: email.trim(), password }; const result = await (kind === "login" ? login : register)(config, body);
      setSession({ token: result.access_token, email: body.email });
      const fresh = { base: config.base, token: result.access_token }; const me = await getMe(fresh);
      if (me.profile) {
        useCabinet.getState().setProfile({ ...me.profile, user_id: me.id });
        const metrics = await getMetrics(fresh, me.profile.id); if (metrics.length) useCabinet.getState().setMetrics(metrics);
      }
    } catch (e) { setError(e instanceof Error ? e.message : "Не удалось войти"); }
    finally { setBusy(false); }
  }
  return <div className="grid items-start gap-6 lg:grid-cols-[0.9fr_1.1fr]">
    <section><p className="text-sm text-primary">Кредитный кабинет</p><h1 className="mt-2 max-w-md text-4xl font-semibold leading-tight">Сначала картина бизнеса, потом предложение.</h1><p className="mt-4 text-muted">Заполните финансовый профиль и сравните условия кредитования.</p></section>
    <form className="glass space-y-4 rounded-lg p-5" onSubmit={(e) => { e.preventDefault(); void submit("login"); }}>
      <label className="block text-sm">Почта<input required type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} className="input-field"/></label>
      <label className="block text-sm">Пароль<input required type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} className="input-field"/></label>
      {error && <p role="alert" className="text-sm text-accent">{error}</p>}
      <div className="grid grid-cols-2 gap-3"><button disabled={busy} className="action-primary">Войти</button><button type="button" disabled={busy} className="action-secondary" onClick={() => void submit("register")}>Создать аккаунт</button></div>
    </form></div>;
}
function ProfileStep() {
  const config = useApiConfig(); const email = useCabinet((s) => s.email) ?? "";
  const [industry, setIndustry] = useState("retail"); const [employees, setEmployees] = useState("4");
  const [credit, setCredit] = useState<CreditContext>({ requested_amount: 1_000_000, desired_term_months: 24,
    company_age_months: 36, region: "central", legal_form: "LLC", purpose: "working_capital", overdue_days: 0,
    collateral_coverage: 0, cash_balance: 1_000_000, debt_balance: 0, monthly_debt_payment: 0 });
  const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  const set = (key: keyof CreditContext, value: string | number) => setCredit((s) => ({ ...s, [key]: value }));
  async function submit() {
    setBusy(true);setError("");
    try { const p = await createProfile(config, { user_email: email, industry, employees: Number(employees), goals: GOALS.find((g) => g[0] === credit.purpose)?.[1], credit_context: credit }); useCabinet.getState().setProfile(p); }
    catch (e) { setError(e instanceof Error ? e.message : "Профиль не сохранён"); } finally { setBusy(false); }
  }
  return <form className="glass mx-auto max-w-3xl space-y-5 rounded-lg p-5" onSubmit={(e) => { e.preventDefault(); void submit(); }}>
    <div><h1 className="text-3xl font-semibold">Профиль и потребность в кредите</h1><p className="mt-2 text-sm text-muted">{email} · Укажите фактические остатки и текущие платежи.</p></div>
    <div className="grid gap-4 sm:grid-cols-2">
      <Select label="Отрасль" value={industry} options={INDUSTRIES} onChange={setIndustry}/>
      <Select label="Регион" value={credit.region} options={REGIONS} onChange={(v) => set("region", v)}/>
      <Select label="Организационная форма" value={credit.legal_form} options={[["LLC", "ООО"], ["IE", "ИП"]]} onChange={(v) => set("legal_form", v)}/>
      <Select label="Цель финансирования" value={credit.purpose} options={GOALS} onChange={(v) => set("purpose", v)}/>
      <Field label="Сотрудники" value={employees} onChange={setEmployees} min={1}/>
      {([ ["requested_amount", "Нужная сумма, ₽"], ["desired_term_months", "Желаемый срок, мес."], ["company_age_months", "Возраст бизнеса, мес."], ["cash_balance", "Денежный резерв, ₽"], ["debt_balance", "Остаток долга, ₽"], ["monthly_debt_payment", "Текущие платежи по долгам, ₽/мес."], ["overdue_days", "Дни просрочки"], ["collateral_coverage", "Покрытие обеспечением, доля (0 — нет)"] ] as const).map(([key,label]) => <Field key={key} label={label} value={String(credit[key])} onChange={(v) => set(key, Number(v))} min={key === "requested_amount" || key === "desired_term_months" ? 1 : 0}/>)}
    </div>
    {error && <p role="alert" className="text-accent">{error}</p>}<button disabled={busy} className="action-primary">{busy ? "Сохраняем…" : "Сохранить профиль"}</button>
  </form>;
}
function previousMonth(): string { const d = new Date(); return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - 1, 1)).toISOString().slice(0,7); }
function parseCsv(text: string): MetricItem[] {
  const lines = text.replace(/^\uFEFF/, "").trim().split(/\r?\n/).filter(Boolean);
  const delimiter = lines[0]?.includes(";") ? ";" : ",";
  const headers = lines[0]?.split(delimiter).map((v) => v.trim());
  if (!headers?.includes("period") || !headers.includes("revenue") || !headers.includes("expenses")) throw new Error("Нужны заголовки period,revenue,expenses; период YYYY-MM.");
  return lines.slice(1).map((line) => {
    const values = line.split(delimiter); const row = Object.fromEntries(headers.map((h,i) => [h, values[i]?.trim()]));
    const number = (name: string, fallback: number) => row[name] == null || row[name] === "" ? fallback : Number(row[name].replace(/\s/g, "").replace(",", "."));
    const revenue = number("revenue", NaN), expenses = number("expenses", NaN);
    const result: MetricItem = { period: row.period, revenue, expenses, cash_flow: number("cash_flow", revenue-expenses), online_share: number("online_share", 0) };
    for (const key of ["cash_balance", "debt_balance", "monthly_debt_payment"] as const) if (row[key]) result[key] = number(key, NaN);
    if (!/^\d{4}-\d{2}$/.test(result.period) || !Number.isFinite(revenue) || !Number.isFinite(expenses)) throw new Error("Проверьте период YYYY-MM и числовые значения в CSV.");
    return result;
  });
}
function MetricsStep() {
  const config = useApiConfig(); const profile = useCabinet((s) => s.profile);
  const [period, setPeriod] = useState(previousMonth()); const [revenue, setRevenue] = useState("1400000");
  const [expenses, setExpenses] = useState("1120000"); const [flow, setFlow] = useState("280000");
  const [months, setMonths] = useState<MetricItem[] | null>(null); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function onFile(file?: File) { if (!file) return; try { const rows = parseCsv(await file.text()); if (!rows.length) throw new Error("В CSV нет отчётов"); setMonths(rows);setError(""); } catch(e) { setMonths(null);setError(e instanceof Error ? e.message : "Ошибка CSV"); } }
  async function submit() {
    if (!profile) return;setBusy(true);setError("");
    try { const values = months ?? [{ period, revenue: Number(revenue), expenses: Number(expenses), cash_flow: Number(flow), online_share: 0 }]; await uploadMetrics(config,profile.id,{ metrics: values }); useCabinet.getState().setMetrics(await getMetrics(config,profile.id)); }
    catch(e) { setError(e instanceof Error ? e.message : "Не удалось сохранить отчёты"); } finally { setBusy(false); }
  }
  return <form className="glass mx-auto max-w-2xl space-y-5 rounded-lg p-5" onSubmit={(e) => { e.preventDefault();void submit(); }}>
    <h1 className="text-3xl font-semibold">Финансовая отчётность</h1><p className="text-sm text-muted">Введите завершённый месяц или загрузите несколько месяцев CSV. Остаток денег и денежный поток учитываются отдельно.</p>
    <div className="grid gap-4 sm:grid-cols-2"><label className="text-sm">Период<input type="month" value={period} onChange={(e) => setPeriod(e.target.value)} className="input-field"/></label><Field label="Выручка, ₽" value={revenue} onChange={setRevenue}/><Field label="Расходы, ₽" value={expenses} onChange={setExpenses}/><Field label="Денежный поток, ₽" value={flow} onChange={setFlow} min={-1e15}/></div>
    <label className="block text-sm">CSV: period,revenue,expenses,cash_flow,online_share<input type="file" accept=".csv,text/csv" className="mt-2 block" onChange={(e) => void onFile(e.target.files?.[0])}/></label>
    {months && <p className="text-sm text-primary">Загружено месяцев: {months.length}</p>}{error && <p role="alert" className="text-sm text-accent">{error}</p>}<button disabled={busy} className="action-primary">{busy ? "Сохраняем…" : "Открыть кабинет"}</button>
  </form>;
}
function Field({ label,value,onChange,min=0 }: { label:string;value:string;onChange:(v:string)=>void;min?:number }) { return <label className="block text-sm">{label}<input required type="number" step="any" min={min} value={value} onChange={(e) => onChange(e.target.value)} className="input-field num"/></label>; }
function Select({ label,value,onChange,options }: { label:string;value:string;onChange:(v:string)=>void;options:string[][] }) { return <label className="block text-sm">{label}<select value={value} onChange={(e) => onChange(e.target.value)} className="input-field">{options.map(([id,text]) => <option key={id} value={id}>{text}</option>)}</select></label>; }
