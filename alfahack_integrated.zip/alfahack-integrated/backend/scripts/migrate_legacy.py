"""Add the integration fields to an existing cabinet database. Back up it first."""
from sqlalchemy import inspect,text
from app.core.database import engine
changes={'profiles':{'credit_context':'JSON'},'metrics':{'cash_balance':'FLOAT','debt_balance':'FLOAT','monthly_debt_payment':'FLOAT'}}
with engine.begin() as connection:
    inspector=inspect(connection)
    for table,columns in changes.items():
        if table not in inspector.get_table_names():continue
        existing={row['name'] for row in inspector.get_columns(table)}
        for name,kind in columns.items():
            if name not in existing:
                connection.execute(text(f'ALTER TABLE {table} ADD COLUMN {name} {kind}'))
                print(f'Added {table}.{name}')
