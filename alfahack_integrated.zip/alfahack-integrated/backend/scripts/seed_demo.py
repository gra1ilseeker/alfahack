"""Create an explicitly synthetic demo account and six financial reports."""
import argparse,json
from pathlib import Path
from app.core.database import Base,engine,SessionLocal
from app.core.config import settings
from app.models import User
from app.services.auth import create_user
from app.services.profile import upsert_profile,add_metrics
from app.ml.runtime import RankingEngine

parser=argparse.ArgumentParser()
parser.add_argument('--email',default='demo@example.com')
parser.add_argument('--password',default='DemoPass123!')
args=parser.parse_args()
Base.metadata.create_all(bind=engine)
model=RankingEngine(settings.ml_bundle_dir)
client=json.loads((settings.ml_bundle_dir/'example_request.json').read_text())['client']
with SessionLocal() as db:
    model.seed_catalog(db)
    user=db.query(User).filter(User.email==args.email).first()
    if user is None:user=create_user(db,args.email,args.password)
    context=dict(requested_amount=client['requested_amount'],desired_term_months=int(client['desired_term_months']),
        company_age_months=int(client['company_age_months']),region=client['region'],legal_form=client['legal_form'],purpose=client['purpose'],
        overdue_days=int(client['overdue_days']),collateral_coverage=client['collateral_coverage'],
        cash_balance=client['cash_last'],debt_balance=client['debt_last'],monthly_debt_payment=client['existing_payment'])
    profile=upsert_profile(db,user,dict(industry=client['sector'],employees=int(client['headcount']),goals='Демонстрационный кассовый разрыв',credit_context=context))
    reports=[dict(period=f'2026-{m:02d}',revenue=client['revenue_mean'],expenses=client['revenue_mean']-client['profit_mean'],
        cash_flow=client['profit_mean'],online_share=.35,cash_balance=client['cash_last'],debt_balance=client['debt_last'],
        monthly_debt_payment=client['existing_payment']) for m in range(4,10)]
    add_metrics(db,profile.id,reports)
print('Synthetic demo account ready:',args.email)
print('Existing account passwords are not changed by this command.')
