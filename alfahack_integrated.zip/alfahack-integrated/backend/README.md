# Бэкенд кабинета

Запуск: `python -m pip install -r requirements.txt`, затем `uvicorn app.main:app --reload`.
Подробный запуск, Docker и контракт CSV — в корневом README.

Модели находятся в `ml_bundle/`, интеграция — `app/ml/`. Архивный `ml_bundle/app.py` сохранён как часть экспорта, а кабинет запускается через `app.main:app`. Для доступа к данным кабинета используется bearer-токен `/auth/login` или `/auth/register`.

Тесты: `python -m pip install -r requirements-dev.txt` и `python -m pytest tests -q`.
Демо: `python -m scripts.seed_demo`.
Старая БД: резервная копия, затем `python -m scripts.migrate_legacy` перед запуском новой версии.
