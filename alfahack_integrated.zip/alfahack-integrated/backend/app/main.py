from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import auth,profile,metrics,dashboard,products,ranking,events,ml
from app.core.database import Base,engine,SessionLocal
from app.core.config import settings
from app.ml.runtime import RankingEngine

@asynccontextmanager
async def lifespan(app):
    Base.metadata.create_all(bind=engine)
    model=RankingEngine(settings.ml_bundle_dir)
    with SessionLocal() as db:model.seed_catalog(db)
    app.state.ranking_engine=model
    yield
    engine.dispose()

app=FastAPI(title=settings.app_name,version='1.0.0',lifespan=lifespan,
    description='Кредитный кабинет с каскадом Ridge → BERT4Rec → сильный ранкер.',
    swagger_ui_parameters={'persistAuthorization':True})
app.add_middleware(CORSMiddleware,allow_origins=settings.cors_origins,
    allow_credentials=False,allow_methods=['GET','POST','DELETE','OPTIONS'],allow_headers=['Authorization','Content-Type'])
for route,prefix,tags in [
    (auth.router,'/auth',['auth']),(profile.router,'/profile',['profile']),
    (metrics.router,'/metrics',['metrics']),(dashboard.router,'/dashboard',['dashboard']),
    (products.router,'/products',['products']),(ranking.router,'/rank',['ranking']),
    (events.router,'/events',['events']),(ml.router,'/ml',['ml']),
]:app.include_router(route,prefix=prefix,tags=tags)

@app.get('/health')
def health():return {'status':'ok','model_version':app.state.ranking_engine.base.manifest['model_version']}
