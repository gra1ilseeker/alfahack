from sqlalchemy.orm import Session
from app.models import Ranking

def save_ranking(db:Session,profile_id:int,result_json:dict)->Ranking:
    ranking=Ranking(profile_id=profile_id,result_json=result_json)
    db.add(ranking);db.commit();db.refresh(ranking)
    return ranking
