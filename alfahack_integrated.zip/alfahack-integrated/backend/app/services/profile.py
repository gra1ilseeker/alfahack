from sqlalchemy.orm import Session
from app.models import Profile,Metric,User,Event,Ranking,DashboardSnapshot


def upsert_profile(db:Session,user:User,values:dict)->Profile:
    profile=db.query(Profile).filter(Profile.user_id==user.id).first()
    if profile is None:
        profile=Profile(user_id=user.id);db.add(profile)
    for key,value in values.items():setattr(profile,key,value)
    db.commit();db.refresh(profile)
    return profile


def get_profile(db:Session,profile_id:int):
    return db.query(Profile).filter(Profile.id==profile_id).first()


def add_metrics(db:Session,profile_id:int,metrics:list[dict]):
    result=[]
    for values in metrics:
        item=db.query(Metric).filter(Metric.profile_id==profile_id,Metric.period==values['period']).first()
        if item is None:item=Metric(profile_id=profile_id);db.add(item)
        for key,value in values.items():setattr(item,key,value)
        result.append(item)
    db.commit()
    return result


def delete_profile_and_user(db:Session,user_id:int):
    profiles=db.query(Profile).filter(Profile.user_id==user_id).all()
    for profile in profiles:
        for model in [Metric,Event,Ranking,DashboardSnapshot]:
            db.query(model).filter(model.profile_id==profile.id).delete(synchronize_session=False)
        db.delete(profile)
    user=db.query(User).filter(User.id==user_id).first()
    if user:db.delete(user)
    db.commit();return True
