"""Single-reference, grouped permutation Shapley estimator for ranking contrasts."""
import numpy as np
import pandas as pd


def explain_catboost_reference(ranker,client,first_offer_id=None,reference_offer_id=None,model_name=None,samples=32):
    name=model_name or ranker.manifest['serving_model']
    frame=ranker.candidates(client)
    frame=frame[frame['eligible']].copy()
    if len(frame)<2:return {'status':'not_applicable','reason':'Fewer than two eligible offers'}
    frame['ranking_score']=ranker.score_candidates(frame,name)
    frame=frame.sort_values(['ranking_score','offer_id'],ascending=[False,True]).reset_index(drop=True)
    first_offer_id=first_offer_id or frame.iloc[0]['offer_id']
    remaining=frame[frame['offer_id'].ne(first_offer_id)]
    reference_offer_id=reference_offer_id or remaining.iloc[0]['offer_id']
    first_rows=frame[frame['offer_id'].eq(first_offer_id)]
    reference_rows=frame[frame['offer_id'].eq(reference_offer_id)]
    if first_rows.empty or reference_rows.empty:raise ValueError('Both explained offers must be eligible')
    first,reference=first_rows.iloc[0],reference_rows.iloc[0]
    matrix=ranker.matrix(pd.DataFrame([first,reference]))
    first_z,reference_z=matrix
    mapping=np.asarray(ranker.schema['encoded_to_raw'])
    groups={feature:np.flatnonzero(mapping==feature) for feature in ranker.schema['features']}
    changed=[feature for feature,indices in groups.items() if not np.array_equal(first_z[indices],reference_z[indices])]
    rng=np.random.default_rng(42)
    paths=[];orders=[]
    for _ in range((samples+1)//2):
        order=rng.permutation(len(changed)).tolist()
        for sequence in [order,order[::-1]]:
            point=reference_z.copy();path=[point.copy()]
            for index in sequence:
                positions=groups[changed[index]];point[positions]=first_z[positions];path.append(point.copy())
            paths.append(np.stack(path));orders.append(sequence)
    paths=paths[:samples];orders=orders[:samples]
    predictions=ranker.predict_matrix(np.concatenate(paths),name).reshape(len(paths),len(changed)+1)
    values=np.zeros((len(paths),len(ranker.schema['features'])))
    feature_index={feature:i for i,feature in enumerate(ranker.schema['features'])}
    for i,order in enumerate(orders):
        for step,index in enumerate(order):values[i,feature_index[changed[index]]]=predictions[i,step+1]-predictions[i,step]
    contributions=values.mean(axis=0)
    scores=ranker.predict_matrix(matrix,name);difference=float(scores[0]-scores[1])
    labels=ranker.schema['labels']
    rows=[dict(feature=feature,label=labels[feature],contribution=float(contributions[i]),
        sampling_std=float(values[:,i].std()),first_value=_scalar(first[feature]),reference_value=_scalar(reference[feature]))
        for i,feature in enumerate(ranker.schema['features'])]
    residual=difference-float(contributions.sum())
    return dict(status='ok',model_name=name,model_version=ranker.manifest['model_version'],
        method='grouped_permutation_shapley_reference_difference',samples=len(paths),random_seed=42,
        target='score(first_offer)-score(reference_offer)',first_offer_id=first_offer_id,reference_offer_id=reference_offer_id,
        first_score=float(scores[0]),reference_score=float(scores[1]),score_difference=difference,
        base_difference=0.,completeness_residual=residual,completeness_ok=abs(residual)<=1e-5,
        attributions=sorted(rows,key=lambda row:abs(row['contribution']),reverse=True),
        scope='Scorer on the requested eligible catalog; single reference offer.',
        interpretation='Positive supports first offer. Monte Carlo Shapley estimate with forward/reverse feature paths; not causal. Correlated feature mixtures may be unrealistic.')


def _scalar(value):return value.item() if isinstance(value,np.generic) else value
