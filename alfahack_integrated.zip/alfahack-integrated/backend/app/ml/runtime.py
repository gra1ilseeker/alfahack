"""Application adapter around the unmodified, checksum-verified exported bundle."""
from copy import copy
from datetime import datetime,timezone
import importlib.util
from pathlib import Path
import sys
import threading
import numpy as np
import pandas as pd
from fastapi import HTTPException
from sqlalchemy.orm import Session
from app.core.config import settings
from app.models import Metric,Event,Product


class _BoundedCatModel:
    """Apply the configured CPU budget to native CatBoost prediction and SHAP."""
    def __init__(self, model, threads):
        self.model=model;self.threads=threads
    def predict(self,*args,**kwargs):
        kwargs.setdefault('thread_count',self.threads)
        return self.model.predict(*args,**kwargs)
    def get_feature_importance(self,*args,**kwargs):
        kwargs.setdefault('thread_count',self.threads)
        return self.model.get_feature_importance(*args,**kwargs)


class RankingEngine:
    def __init__(self,bundle_dir:Path):
        import torch
        torch.set_num_threads(settings.ml_threads)
        spec=importlib.util.spec_from_file_location('cabinet_exported_credit_ranker',bundle_dir/'credit_ranker.py')
        module=importlib.util.module_from_spec(spec)
        sys.modules[spec.name]=module;spec.loader.exec_module(module)
        from app.ml.explainers import explain_catboost_reference
        class ServingRanker(module.CreditRanker):
            def explain(self,client,first_offer_id=None,reference_offer_id=None,model_name=None):
                name=model_name or self.manifest['serving_model']
                kind,_=self._load(name)
                if kind=='catboost' and settings.catboost_explainer=='permutation':
                    return explain_catboost_reference(self,client,first_offer_id,reference_offer_id,name)
                return super().explain(client,first_offer_id,reference_offer_id,model_name)
        self.base=ServingRanker(bundle_dir)
        # Warm immutable inference weights once, before accepting requests.
        for name in self.base.available_models:
            kind,loaded=self.base._load(name)
            if kind=='catboost':
                self.base._loaded[name]=(kind,[_BoundedCatModel(model,settings.ml_threads) for model in loaded])
        if self.base.manifest.get('sequence_model'):
            self.base.bert_history_scores([str(self.base.offers.iloc[0]['offer_id'])])
        self._inference_lock=threading.RLock()

    def scope(self,offer_ids:list[str]):
        # Per-request catalog; never mutate the shared engine or its offers.
        scoped=copy(self.base)
        scoped.offers=self.base.offers[self.base.offers['offer_id'].isin(offer_ids)].copy()
        if scoped.offers.empty:raise HTTPException(status_code=422,detail='Нет предложений из ML-каталога')
        return scoped

    def seed_catalog(self,db:Session):
        existing={str((p.requirements_json or {}).get('offer_id')):p for p in db.query(Product).all()}
        titles={'working_capital':'Оборотный кредит','equipment':'Кредит на оборудование','credit_line':'Кредитная линия'}
        for offer in self.base.offers.to_dict('records'):
            product=existing.get(str(offer['offer_id']))
            if product is None:product=Product();db.add(product)
            product.name=f"{titles.get(offer['product_type'],offer['product_type'])} · {offer['lender_id']} · {int(offer['offer_term_months'])} мес."
            product.type=offer['product_type']
            product.rate=float(offer['annual_rate'])*100
            product.min_limit=float(offer['min_amount']);product.max_limit=float(offer['max_amount'])
            product.requirements_json={
                'offer_id':str(offer['offer_id']),'lender_id':str(offer['lender_id']),
                'purpose':str(offer['offer_purpose']),'term_months':int(offer['offer_term_months']),
                'upfront_fee_rate':float(offer['upfront_fee_rate']),
                'collateral_required':bool(offer['collateral_required']),
                'min_age_months':int(offer['min_age_months']),
                'demo_catalog':bool(self.base.manifest.get('synthetic_catalog',False)),
            }
        db.commit()

    def client_profile(self,db:Session,profile):
        context=profile.credit_context or {}
        needed=['requested_amount','desired_term_months','company_age_months','region','legal_form',
                'purpose','overdue_days','collateral_coverage','cash_balance','debt_balance','monthly_debt_payment']
        missing=[field for field in needed if context.get(field) is None]
        if not profile.industry:missing.append('industry')
        if profile.employees is None:missing.append('employees')
        if missing:raise HTTPException(status_code=422,detail='Дополните кредитный профиль: '+', '.join(missing))
        current_month=datetime.now(timezone.utc).strftime('%Y-%m')
        metrics=db.query(Metric).filter(Metric.profile_id==profile.id,Metric.period<current_month).order_by(Metric.period.desc(),Metric.id.desc()).all()
        # One latest report for each completed month, at most twelve months.
        seen=set();reports=[]
        for metric in metrics:
            if metric.period in seen:continue
            seen.add(metric.period);reports.append(metric)
            if len(reports)==12:break
        reports=list(reversed(reports))
        if not reports:raise HTTPException(status_code=422,detail='Нужен хотя бы один завершённый месяц финансовой отчётности (YYYY-MM)')
        revenues=np.asarray([m.revenue for m in reports],dtype=float)
        latest=reports[-1]
        def balance(field):
            monthly=getattr(latest,field)
            return float(context[field] if monthly is None else monthly)
        client=dict(company_id=f'profile-{profile.id}',sector=profile.industry,region=context['region'],
            legal_form=context['legal_form'],purpose=context['purpose'],requested_amount=context['requested_amount'],
            desired_term_months=context['desired_term_months'],company_age_months=context['company_age_months'],
            headcount=profile.employees,overdue_days=context['overdue_days'],collateral_coverage=context['collateral_coverage'],
            revenue_mean=float(revenues.mean()),revenue_cv=float(revenues.std()/max(revenues.mean(),1)),
            profit_mean=float(np.mean([m.revenue-m.expenses for m in reports])),
            cash_last=balance('cash_balance'),debt_last=balance('debt_balance'),existing_payment=balance('monthly_debt_payment'))
        provenance=dict(financial_months=len(reports),first_period=reports[0].period,last_period=reports[-1].period,
            report_availability_assumption='Completed month available at the beginning of the next month',
            balance_source='latest monthly report when supplied; otherwise explicit credit profile snapshot')
        return self.base.normalize_client(client),provenance

    def history(self,db:Session,profile_id:int):
        # Only explicit selection/interest events are used, never automatic views.
        rows=db.query(Event).filter(Event.profile_id==profile_id,Event.event_type.in_(['offer_selected','application_draft'])).order_by(Event.created_at.desc(),Event.id.desc()).limit(200).all()
        return [str(e.payload['offer_id']) for e in reversed(rows) if isinstance(e.payload,dict) and e.payload.get('offer_id')]

    def rank(self,db:Session,profile,products:list[Product],k:int=3,explain:bool=True,mode:str='auto'):
        mapping={str((p.requirements_json or {}).get('offer_id')):p for p in products if (p.requirements_json or {}).get('offer_id')}
        valid=set(self.base.offers['offer_id'])
        mapping={key:value for key,value in mapping.items() if key in valid}
        if not mapping:raise HTTPException(status_code=422,detail='Выбранные продукты отсутствуют в загруженном ML-каталоге')
        client,provenance=self.client_profile(db,profile)
        history=self.history(db,profile.id)
        scoped=self.scope(list(mapping))
        # Some explainers write module-level gradient state. Serialize small CPU inference calls.
        with self._inference_lock:
            result=scoped.recommend_cascade(client,history,k=k,explain=explain,mode=mode)
        for item in result['recommendations']:
            product=mapping[item['offer_id']]
            item['product_id']=product.id
            item['note']=f"{item['estimated_payment']:,.0f} ₽/мес. · {int(item['offer_term_months'])} мес. · ставка {item['annual_rate']*100:.1f}%".replace(',', ' ')
        checked=scoped.candidates(client)
        labels={'purpose':'Другая цель финансирования','amount':'Сумма вне лимитов предложения',
                'age':'Недостаточный возраст бизнеса','overdue':'Превышен порог просрочки',
                'cashflow':'Недостаточное покрытие платежа прибылью','collateral':'Недостаточно обеспечения'}
        result['exclusions']=[dict(product_id=mapping[row['offer_id']].id,offer_id=row['offer_id'],
            reasons=row['exclusion_reasons'].split(','),note='; '.join(labels.get(r,r) for r in row['exclusion_reasons'].split(',')))
            for row in checked.loc[~checked['eligible']].to_dict('records')]
        result['input_context']=provenance
        result['history_event_count']=len(history)
        result['synthetic_catalog']=bool(self.base.manifest.get('synthetic_catalog',False))
        result['label_source']=self.base.manifest.get('label_source')
        result['requested_amount']=client['requested_amount']
        result['excluded_count']=len(scoped.offers)-result['eligible_count']
        result['selection_event_types']=['offer_selected','application_draft']
        return result
