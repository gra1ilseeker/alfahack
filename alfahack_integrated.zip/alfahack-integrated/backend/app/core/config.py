import os
from pathlib import Path

BACKEND_ROOT = Path(__file__).resolve().parents[2]

class Settings:
    app_name = os.getenv('APP_NAME', 'Вектор — кредитный кабинет')
    database_url = os.getenv('DATABASE_URL', f'sqlite:///{BACKEND_ROOT / "data" / "cabinet.db"}')
    ml_bundle_dir = Path(os.getenv('ML_BUNDLE_DIR', str(BACKEND_ROOT / 'ml_bundle'))).resolve()
    cors_origins = [s.strip() for s in os.getenv('CORS_ORIGINS', 'http://localhost:8080,http://127.0.0.1:8080').split(',') if s.strip()]
    debug = os.getenv('DEBUG', 'false').lower() == 'true'
    ml_threads = int(os.getenv('ML_THREADS', '2'))
    catboost_explainer = os.getenv('CATBOOST_EXPLAINER', 'permutation')

settings = Settings()
if settings.database_url.startswith('sqlite:///') and settings.database_url != 'sqlite:///:memory:':
    Path(settings.database_url.removeprefix('sqlite:///')).parent.mkdir(parents=True, exist_ok=True)
