from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.orm import Session
from app.api.deps import get_db,get_current_user,get_owned_profile
from app.schemas.profile import ProfileCreate,ProfileResponse
from app.services.profile import upsert_profile

router=APIRouter()

@router.post('/',response_model=ProfileResponse)
def create_profile(payload:ProfileCreate,db:Session=Depends(get_db),user=Depends(get_current_user)):
    if payload.user_email is not None and str(payload.user_email).lower()!=user.email.lower():
        raise HTTPException(status_code=403,detail='Нельзя изменить чужой профиль')
    values=payload.model_dump(exclude={'user_email','password'})
    return upsert_profile(db,user,values)

@router.get('/{profile_id}',response_model=ProfileResponse)
def get_profile(profile_id:int,db:Session=Depends(get_db),user=Depends(get_current_user)):
    return get_owned_profile(profile_id,db,user)
