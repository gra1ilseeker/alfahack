from fastapi import APIRouter,Depends,HTTPException,Request
from sqlalchemy.orm import Session
from app.api.deps import get_db,get_current_user,get_owned_profile
from app.models import Product,Ranking
from app.schemas.ranking import RankRequest,RankResponse
from app.services.ranking import save_ranking

router=APIRouter()

@router.post('/products',response_model=RankResponse)
def rank_products(payload:RankRequest,request:Request,db:Session=Depends(get_db),user=Depends(get_current_user)):
    profile=get_owned_profile(payload.profile_id,db,user)
    ids=set(payload.products)
    products=db.query(Product).filter(Product.id.in_(ids)).all()
    if len(products)!=len(ids):raise HTTPException(status_code=422,detail='Неизвестные ID продуктов')
    try:
        result=request.app.state.ranking_engine.rank(db,profile,products,payload.k,payload.explain,payload.mode)
    except HTTPException:raise
    except ValueError as error:raise HTTPException(status_code=422,detail=str(error)) from error
    except Exception as error:
        import logging
        logging.getLogger(__name__).exception('ML inference failed')
        raise HTTPException(status_code=503,detail='Модель временно недоступна; результат не подменяется заглушкой') from error
    ranking=save_ranking(db,profile.id,result)
    return RankResponse(ranking_id=ranking.id,result=result)

@router.get('/{ranking_id}',response_model=RankResponse)
def get_ranking(ranking_id:int,db:Session=Depends(get_db),user=Depends(get_current_user)):
    ranking=db.query(Ranking).filter(Ranking.id==ranking_id).first()
    if ranking is None:raise HTTPException(status_code=404,detail='Результат не найден')
    get_owned_profile(ranking.profile_id,db,user)
    return RankResponse(ranking_id=ranking.id,result=ranking.result_json)
