from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.orm import Session
from app.api.deps import get_db,get_current_user,get_owned_profile
from app.models import Product
from app.schemas.event import EventCreate
from app.services.event import log_event

router=APIRouter()

@router.post('/')
def create_event(payload:EventCreate,db:Session=Depends(get_db),user=Depends(get_current_user)):
    if payload.profile_id is None:raise HTTPException(status_code=422,detail='Укажите profile_id')
    get_owned_profile(payload.profile_id,db,user)
    data=payload.payload
    if data is not None and not isinstance(data,dict):raise HTTPException(status_code=422,detail='payload должен быть объектом')
    data=dict(data or {})
    if payload.event_type in {'product_view','offer_selected','application_draft'}:
        product_id=data.get('product_id')
        product=db.query(Product).filter(Product.id==product_id).first()
        if product is None:raise HTTPException(status_code=422,detail='Неизвестный продукт')
        data['offer_id']=(product.requirements_json or {}).get('offer_id')
    event=log_event(db,payload.profile_id,payload.event_type,data)
    return {'id':event.id}
