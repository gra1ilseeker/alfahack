from fastapi import APIRouter,Depends,Request,HTTPException
from pydantic import BaseModel,Field
from sqlalchemy.orm import Session
from app.api.deps import get_current_user,get_db,get_owned_profile

router=APIRouter()

@router.get('/status')
def status(request:Request,user=Depends(get_current_user)):
    manifest=request.app.state.ranking_engine.base.manifest
    return {'model_version':manifest['model_version'],'serving_model':manifest['serving_model'],
        'models':list(manifest['models']),'cascade':manifest.get('cascade'),
        'sequence_model':manifest.get('sequence_model'),'synthetic_catalog':manifest.get('synthetic_catalog',False)}

@router.get('/features')
def features(request:Request,user=Depends(get_current_user)):
    return request.app.state.ranking_engine.base.schema

@router.get('/feature-importance')
def importance(request:Request,model_name:str|None=None,user=Depends(get_current_user)):
    try:return request.app.state.ranking_engine.base.feature_importance(model_name)
    except ValueError as error:raise HTTPException(status_code=422,detail=str(error)) from error

class HistoryExplanation(BaseModel):
    profile_id:int
    product_id:int
    limit:int=Field(default=8,ge=1,le=50)

@router.post('/explain-history')
def explain_history(payload:HistoryExplanation,request:Request,db:Session=Depends(get_db),user=Depends(get_current_user)):
    from app.models import Product
    get_owned_profile(payload.profile_id,db,user)
    product=db.query(Product).filter(Product.id==payload.product_id).first()
    if product is None:raise HTTPException(status_code=404,detail='Продукт не найден')
    engine=request.app.state.ranking_engine
    try:
        with engine._inference_lock:
            return engine.base.explain_history(engine.history(db,payload.profile_id),product.requirements_json['offer_id'],payload.limit)
    except ValueError as error:raise HTTPException(status_code=422,detail=str(error)) from error
