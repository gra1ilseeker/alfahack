from fastapi import APIRouter,Depends
from sqlalchemy.orm import Session
from app.api.deps import get_db,get_current_user,get_owned_profile
from app.models import Metric
from app.schemas.profile import MetricsUpload,MetricItem
from app.services.profile import add_metrics

router=APIRouter()

@router.post('/{profile_id}')
def upload_metrics(profile_id:int,payload:MetricsUpload,db:Session=Depends(get_db),user=Depends(get_current_user)):
    get_owned_profile(profile_id,db,user)
    items=add_metrics(db,profile_id,[m.model_dump() for m in payload.metrics])
    return {'count':len(items)}

@router.get('/{profile_id}',response_model=list[MetricItem])
def get_metrics(profile_id:int,db:Session=Depends(get_db),user=Depends(get_current_user)):
    get_owned_profile(profile_id,db,user)
    fields=MetricItem.model_fields
    return [{f:getattr(m,f) for f in fields} for m in db.query(Metric).filter(Metric.profile_id==profile_id).order_by(Metric.period).all()]
