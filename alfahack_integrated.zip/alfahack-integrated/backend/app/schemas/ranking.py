from typing import Any,Literal
from pydantic import BaseModel,Field

class RankRequest(BaseModel):
    profile_id:int
    products:list[int]=Field(min_length=1,max_length=1000)
    k:int=Field(default=3,ge=1,le=50)
    explain:bool=True
    mode:Literal['auto','cheap','deep','strong']='auto'

class RankResponse(BaseModel):
    ranking_id:int
    result:dict[str,Any]
