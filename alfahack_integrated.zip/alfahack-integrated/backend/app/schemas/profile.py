from datetime import date,datetime,timezone
import re
from typing import Literal
from pydantic import BaseModel,ConfigDict,EmailStr,Field,field_validator

class CreditContext(BaseModel):
    model_config=ConfigDict(extra='forbid',allow_inf_nan=False)
    requested_amount:float=Field(gt=0)
    desired_term_months:int=Field(ge=1,le=120)
    company_age_months:int=Field(ge=0,le=1200)
    region:Literal['central','north_west','siberia','south','ural','volga']
    legal_form:Literal['LLC','IE']
    purpose:Literal['working_capital','equipment','cash_gap']
    overdue_days:int=Field(default=0,ge=0,le=3650)
    collateral_coverage:float=Field(ge=0)
    cash_balance:float=Field(ge=0)
    debt_balance:float=Field(ge=0)
    monthly_debt_payment:float=Field(ge=0)

class ProfileCreate(BaseModel):
    user_email:EmailStr|None=None
    password:str|None=None # Accepted for compatibility; authenticated identity comes from the bearer token.
    industry:Literal['it','logistics','manufacturing','retail','services']
    revenue_band:str|None=None
    employees:int=Field(ge=1,le=1000000)
    goals:str|None=None
    credit_context:CreditContext

class ProfileResponse(BaseModel):
    model_config=ConfigDict(from_attributes=True)
    id:int
    user_id:int
    industry:str|None
    revenue_band:str|None
    employees:int|None
    goals:str|None
    credit_context:CreditContext|None=None

class MetricItem(BaseModel):
    model_config=ConfigDict(allow_inf_nan=False)
    period:str
    revenue:float=Field(ge=0)
    expenses:float=Field(ge=0)
    cash_flow:float
    online_share:float=Field(default=0,ge=0,le=1)
    cash_balance:float|None=Field(default=None,ge=0)
    debt_balance:float|None=Field(default=None,ge=0)
    monthly_debt_payment:float|None=Field(default=None,ge=0)

    @field_validator('period')
    @classmethod
    def valid_period(cls,value):
        if not re.fullmatch(r'\d{4}-\d{2}',value):
            raise ValueError('Период должен быть YYYY-MM, например 2026-09')
        date.fromisoformat(value+'-01')
        if value >= datetime.now(timezone.utc).strftime('%Y-%m'):
            raise ValueError('Нужен завершённый отчётный месяц')
        return value

class MetricsUpload(BaseModel):
    metrics:list[MetricItem]=Field(min_length=1,max_length=120)

    @field_validator('metrics')
    @classmethod
    def unique_periods(cls,items):
        if len({m.period for m in items})!=len(items):raise ValueError('Периоды должны быть уникальны')
        return items
