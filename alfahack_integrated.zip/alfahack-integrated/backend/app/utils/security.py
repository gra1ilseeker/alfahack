import hashlib
import hmac
import secrets


def hash_password(password:str)->str:
    salt=secrets.token_hex(16)
    iterations=260000
    digest=hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),iterations).hex()
    return f'pbkdf2_sha256${iterations}${salt}${digest}'


def verify_password(password:str,password_hash:str)->bool:
    if password_hash.startswith('pbkdf2_sha256$'):
        try:
            _,rounds,salt,expected=password_hash.split('$')
            actual=hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),int(rounds)).hex()
            return hmac.compare_digest(actual,expected)
        except (ValueError,TypeError):return False
    # Previously created project accounts used an unsalted SHA-256 digest.
    return hmac.compare_digest(hashlib.sha256(password.encode()).hexdigest(),password_hash)
