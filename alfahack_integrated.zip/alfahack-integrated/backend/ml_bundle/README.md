# SME credit offer ranking backend bundle

## Start

Use Python 3.10+ and install the appropriate PyTorch build for your CPU/GPU before installing requirements if needed. Runtime versions used for export are in environment.json. requirements.txt pins exported inference dependencies; requirements-api.txt adds FastAPI/Uvicorn.

```bash
python -m pip install -r requirements-api.txt
python smoke_test.py
uvicorn app:app --host 0.0.0.0 --port 8000
```

The directory containing app.py must be the working directory. CREDIT_BUNDLE_DIR optionally selects another exported bundle directory. Open http://localhost:8000/docs for the request schema. No server is started by the notebook.

```bash
curl -X POST http://localhost:8000/recommend -H 'Content-Type: application/json' --data-binary @example_request.json
```

```python
from credit_ranker import CreditRanker
ranker = CreditRanker('.')
response = ranker.recommend(client_profile, k=3, explain=True)
explanation = ranker.explain(client_profile, first_offer_id='...', reference_offer_id='...')
```

## Input

client_profile is an aggregated financial profile at the request timestamp. feature_schema.json lists required numeric/categorical fields. cash_months and requested_to_revenue are recomputed by the backend. company_id is optional metadata and is not a model feature. example_request.json contains one SYNTHETIC client.

Aggregate raw company/application/monthly-finance tables using notebook section 4. Do not send future financial reports. Amounts and monthly finance figures must use the same currency and units as training. Rates/fees are fractions, not percentages.

## Output

ranking_score orders eligible offers within one request. It is not approval/default probability. No eligible offers returns status=no_eligible_offers. Eligibility exclusions are explicit rule outputs. No endpoint trains models.

/recommend supports model_name and explain. /explain compares the two supplied eligible offers; absent IDs select top-1 vs top-2. Positive attribution supports the first offer. The result includes completeness_residual and completeness_ok.

## Models and explanations

models/*.pt: CPU state_dict checkpoints plus architecture, loaded with torch.load(weights_only=True). models/*.cbm: trained CatBoost models, present only if available. preprocessor.joblib and feature_schema.json must travel with weights. For MLP/TabM the class/architecture is reconstructed by credit_ranker.py.

Global importance is grouped permutation importance on validation NDCG@3. Local explanation uses Tree SHAP difference for CatBoost and Integrated Gradients from reference to first offer for MLP/TabM. One-hot contributions are summed into raw feature names. Attributions concern the scorer, not the eligibility rules or a bank's decision. They are not causal effects. IG paths may interpolate categorical encodings; unchanged client features receive zero path attribution even if they affect interactions.

checksums.json checks integrity before deserializing. Load only a trusted bundle: joblib is Python deserialization, and checksums alone do not authenticate files.

## Scope

This bundle was trained on the data described in bundle_manifest.json. The demo labels/catalog are fictional. Reproducing a utility formula does not validate real SME preferences. Expert/interaction data and an appropriate held-out evaluation are required for real use.

## BERT4Rec and cascade (API v2)

/recommend uses the cascade by default; use_cascade=false requests the direct tabular model.
Send history as a list of offer_id values from oldest to newest, all observed before the query. Unknown IDs are skipped. No history triggers a strong-tabular fallback when escalation is required.
The stages are eligibility -> cheap Ridge -> optional BERT retrieval -> strong tabular reranker. The gate is calibrated on validation utility labels; its margin is not a probability. Small catalogs may gain no latency benefit.
example_api_request.json is ready for POST /recommend; example_cascade_request.json is ready for ranker.recommend_cascade(**request). /recommend-cascade explicitly invokes the cascade; /explain-history reports non-additive item-deletion sensitivity.
The supplied event histories are simulated when history_source begins with synthetic. They are not real clicks or loan originations. Next-item metrics and utility-ranking metrics describe different targets.
Use models/bert4rec.pt together with sequence_vocabulary.json and bert4rec.py. Models and catalog travel together. /health exposes the active gate policy.
