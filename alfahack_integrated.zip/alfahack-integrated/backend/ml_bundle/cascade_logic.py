"""Shared deterministic cascade routing used by the notebook and backend."""
import time
import numpy as np


def route_candidates(frame,cheap_scores,strong_predict,sequence_predict,history,config,k=3,mode='auto'):
    if mode not in ['auto','cheap','deep','strong']:
        raise ValueError('mode must be auto, cheap, deep or strong')
    if len(frame)==0:raise ValueError('route_candidates requires eligible candidates')
    if not isinstance(k,int) or isinstance(k,bool) or not 1<=k<=50:
        raise ValueError('k must be an integer between 1 and 50')
    if history is None:history=[]
    if not isinstance(history,(list,tuple)) or any(not isinstance(x,str) for x in history):
        raise ValueError('history must contain chronological offer_id strings')
    cheap=np.asarray(cheap_scores,dtype=float).reshape(-1)
    if len(cheap)!=len(frame) or not np.isfinite(cheap).all():raise ValueError('Invalid cheap scores')
    ids=frame['offer_id'].astype(str).to_numpy()
    order=np.lexsort((ids,-cheap))
    raw_gap=float(cheap[order[0]]-cheap[order[1]]) if len(order)>1 else 0.
    gap=raw_gap/max(float(np.std(cheap)),1e-6)
    threshold=float(config['margin_threshold'])
    chosen=np.arange(len(frame))
    timings={'bert_ms':0.,'strong_ms':0.}
    history_info=dict(known_count=0,unknown_count=0,used_count=0,truncated_count=0)
    used_bert=False
    if len(frame)==1:
        path='single_offer';scores=cheap
    elif mode=='cheap' or (mode=='auto' and gap>=threshold):
        path='cheap_margin_exit';scores=cheap
    else:
        path='strong_all_candidates' if mode=='strong' else 'cold_start_strong'
        if mode!='strong' and len(history)>0 and sequence_predict is not None:
            start=time.perf_counter()
            affinity,history_info=sequence_predict(history)
            timings['bert_ms']=(time.perf_counter()-start)*1000
            if affinity is not None:
                used_bert=True
                history_scores=np.asarray([affinity.get(item,-1e30) for item in ids],dtype=float)
                bert_order=np.lexsort((ids,-history_scores))
                top_m=max(k,int(config['retrieval_top_m']))
                keep_cheap=max(k,int(config.get('keep_cheap_k',3)))
                selected=set(bert_order[:top_m].tolist())|set(order[:keep_cheap].tolist())
                chosen=np.asarray(sorted(selected),dtype=np.int64)
                path='bert_retrieve_then_strong'
            else:path='unknown_history_strong'
        start=time.perf_counter()
        scores=np.asarray(strong_predict(frame.iloc[chosen]),dtype=float).reshape(-1)
        timings['strong_ms']=(time.perf_counter()-start)*1000
        if len(scores)!=len(chosen) or not np.isfinite(scores).all():raise ValueError('Invalid strong scores')
        ranked=np.lexsort((ids[chosen],-scores))
        order=chosen[ranked]
        scores=scores[ranked]
        return dict(order=order.tolist(),scores=scores.tolist(),candidate_indices=chosen.tolist(),
            path=path,fast_path=False,used_bert=used_bert,margin_proxy=gap,margin_threshold=threshold,
            eligible_count=len(frame),reranker_candidates=len(chosen),history=history_info,timings_ms=timings)
    return dict(order=order.tolist(),scores=cheap[order].tolist(),candidate_indices=chosen.tolist(),
        path=path,fast_path=True,used_bert=used_bert,margin_proxy=gap,margin_threshold=threshold,
        eligible_count=len(frame),reranker_candidates=0,history=history_info,timings_ms=timings)


def ordinal_scores(length,result):
    scores=np.full(length,-1e6,dtype=float)
    for rank,index in enumerate(result['order']):scores[index]=len(result['order'])-rank
    return scores
