"""Small BERT4Rec-style Cloze recommender, implemented in PyTorch."""
import numpy as np
import torch
from torch import nn

class BERT4Rec(nn.Module):
    def __init__(self,n_items,max_len=12,hidden=32,heads=2,layers=2,dropout=.1):
        super().__init__()
        self.n_items=n_items
        self.max_len=max_len
        self.pad_id=0
        self.mask_id=n_items+1
        self.item_embedding=nn.Embedding(n_items+2,hidden,padding_idx=0)
        self.position_embedding=nn.Embedding(max_len,hidden)
        self.input_norm=nn.LayerNorm(hidden)
        self.dropout=nn.Dropout(dropout)
        layer=nn.TransformerEncoderLayer(hidden,heads,dim_feedforward=hidden*4,
            dropout=dropout,activation='gelu',batch_first=True,norm_first=False)
        self.encoder=nn.TransformerEncoder(layer,layers,enable_nested_tensor=False)
        self.output_norm=nn.LayerNorm(hidden)
        self.output_bias=nn.Parameter(torch.zeros(n_items))
        self.apply(self._initialize)
        with torch.no_grad():self.item_embedding.weight[0].zero_()

    @staticmethod
    def _initialize(module):
        if isinstance(module,(nn.Linear,nn.Embedding)):
            nn.init.normal_(module.weight,mean=0.,std=.02)
            if isinstance(module,nn.Linear) and module.bias is not None:
                nn.init.zeros_(module.bias)

    def forward(self,tokens):
        positions=torch.arange(tokens.shape[1],device=tokens.device)[None,:]
        x=self.item_embedding(tokens)+self.position_embedding(positions)
        x=self.dropout(self.input_norm(x))
        # Bidirectional attention; only padding positions are hidden.
        x=self.encoder(x,src_key_padding_mask=tokens.eq(self.pad_id),is_causal=False)
        x=self.output_norm(x)
        # Only actual catalog items are predicted; PAD and MASK are excluded.
        return torch.nn.functional.linear(x,self.item_embedding.weight[1:self.n_items+1],self.output_bias)


def encode_history(history,item_to_id,max_len):
    if history is None:history=[]
    if not isinstance(history,(list,tuple)) or any(not isinstance(x,str) for x in history):
        raise ValueError('history must be a list of offer_id strings, oldest first')
    if len(history)>10000:raise ValueError('history is too long; send the recent events')
    known=[item_to_id[item] for item in history if item in item_to_id]
    if not known:
        return None,dict(known_count=0,unknown_count=len(history),used_count=0,truncated_count=0)
    used=known[-(max_len-1):]
    tokens=np.zeros(max_len,dtype=np.int64)
    tokens[:len(used)]=used
    tokens[len(used)]=len(item_to_id)+1
    return (tokens,len(used)),dict(known_count=len(known),unknown_count=len(history)-len(known),
        used_count=len(used),truncated_count=len(known)-len(used))


def score_history(model,history,item_to_id):
    encoded,info=encode_history(history,item_to_id,model.max_len)
    if encoded is None:return None,info
    tokens,position=encoded
    model.eval()
    with torch.no_grad():
        scores=model(torch.as_tensor(tokens,dtype=torch.long)[None,:])[0,position].numpy()
    ordered=sorted(item_to_id,key=item_to_id.get)
    return dict(zip(ordered,scores.astype(float).tolist())),info
