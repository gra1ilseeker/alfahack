"""Run: uvicorn app:app --host 0.0.0.0 --port 8000"""
from contextlib import asynccontextmanager
from pathlib import Path
import os
from typing import Any
from fastapi import FastAPI,HTTPException
from pydantic import BaseModel,Field
from credit_ranker import CreditRanker

class RecommendationRequest(BaseModel):
    client:dict[str,Any]
    history:list[str]=Field(default_factory=list,max_length=1000)
    k:int=Field(default=3,ge=1,le=50)
    model_name:str|None=None
    explain:bool=False
    use_cascade:bool=True
    mode:str='auto'

class ExplanationRequest(BaseModel):
    client:dict[str,Any]
    first_offer_id:str|None=None
    reference_offer_id:str|None=None
    model_name:str|None=None

class HistoryExplanationRequest(BaseModel):
    history:list[str]=Field(max_length=1000)
    target_offer_id:str
    limit:int=Field(default=8,ge=1,le=50)

@asynccontextmanager
async def lifespan(app):
    root=os.environ.get('CREDIT_BUNDLE_DIR',str(Path(__file__).resolve().parent))
    app.state.ranker=CreditRanker(root)
    yield

app=FastAPI(title='SME Credit Ranking Cascade',version='2.0',lifespan=lifespan)

@app.get('/health')
def health():
    ranker=app.state.ranker
    return dict(status='ok',model_version=ranker.manifest['model_version'],
        serving_model=ranker.manifest['serving_model'],models=ranker.available_models,
        sequence_model=ranker.manifest.get('sequence_model'),cascade=ranker.manifest.get('cascade'))

@app.get('/features')
def features():return app.state.ranker.schema

@app.get('/feature-importance')
def feature_importance(model_name:str|None=None):
    try:return app.state.ranker.feature_importance(model_name)
    except ValueError as error:raise HTTPException(status_code=422,detail=str(error)) from error

@app.post('/recommend')
def recommend(request:RecommendationRequest):
    try:
        ranker=app.state.ranker
        if request.use_cascade:
            strong=ranker.manifest['cascade']['strong_model']
            if request.model_name is not None and request.model_name!=strong:
                raise ValueError('Cascade policy was calibrated for its strong model; set use_cascade=false for another model')
            return ranker.recommend_cascade(request.client,request.history,request.k,request.explain,request.mode)
        return ranker.recommend(request.client,request.k,request.model_name,request.explain)
    except ValueError as error:raise HTTPException(status_code=422,detail=str(error)) from error

@app.post('/recommend-cascade')
def recommend_cascade(request:RecommendationRequest):
    try:return app.state.ranker.recommend_cascade(request.client,request.history,request.k,request.explain,request.mode)
    except ValueError as error:raise HTTPException(status_code=422,detail=str(error)) from error

@app.post('/explain')
def explain(request:ExplanationRequest):
    try:return app.state.ranker.explain(request.client,request.first_offer_id,request.reference_offer_id,request.model_name)
    except ValueError as error:raise HTTPException(status_code=422,detail=str(error)) from error

@app.post('/explain-history')
def explain_history(request:HistoryExplanationRequest):
    try:return app.state.ranker.explain_history(request.history,request.target_offer_id,request.limit)
    except ValueError as error:raise HTTPException(status_code=422,detail=str(error)) from error
