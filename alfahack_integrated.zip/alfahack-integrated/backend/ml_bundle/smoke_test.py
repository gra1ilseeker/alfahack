from pathlib import Path
import json
import numpy as np
from credit_ranker import CreditRanker
root=Path(__file__).resolve().parent
ranker=CreditRanker(root)
request=json.loads((root/'example_request.json').read_text())
expected=json.loads((root/'example_response.json').read_text())
actual=ranker.recommend(**request)
a=actual['recommendations'];b=expected['recommendations']
assert [x['offer_id'] for x in a]==[x['offer_id'] for x in b]
assert np.allclose([x['ranking_score'] for x in a],[x['ranking_score'] for x in b],atol=1e-5,rtol=1e-5)
assert actual['explanation']['completeness_ok']
print('OK: restored predictions, ranking and explanation match the notebook')

request=json.loads((root/'example_cascade_request.json').read_text())
expected=json.loads((root/'example_cascade_response.json').read_text())
actual=ranker.recommend_cascade(**request)
assert [x['offer_id'] for x in actual['recommendations']]==[x['offer_id'] for x in expected['recommendations']]
assert actual['trace']['path']==expected['trace']['path']
assert np.allclose([x['ranking_score'] for x in actual['recommendations']],[x['ranking_score'] for x in expected['recommendations']],atol=1e-5,rtol=1e-5)
if actual.get('explanation',{}).get('status')=='ok':assert actual['explanation']['completeness_ok']
print('OK: cascade, sequence checkpoint and gate policy restored')
