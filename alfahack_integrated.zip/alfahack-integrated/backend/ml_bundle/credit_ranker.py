from pathlib import Path
import hashlib,json
import joblib
import numpy as np
import pandas as pd
import torch
from torch import nn

def make_candidates(client_frame, offer_frame, max_overdue_days, min_estimated_dscr):
    p = client_frame.merge(offer_frame, how="cross").copy()
    amount = p["requested_amount"].to_numpy(dtype=float)
    rate = p["annual_rate"].to_numpy(dtype=float) / 12
    months = p["offer_term_months"].to_numpy(dtype=float)
    denominator = 1 - np.power(1 + rate, -months)
    payment = np.divide(amount * rate, denominator, out=amount / months, where=rate != 0)
    p["estimated_payment"] = payment
    p["estimated_total_cost_ratio"] = np.maximum(
        (payment * months + amount * p["upfront_fee_rate"].to_numpy() - amount) / amount, 0)
    free_cash = (p["profit_mean"] - p["existing_payment"]).clip(lower=1)
    p["payment_to_free_cash"] = p["estimated_payment"] / free_cash
    p["term_mismatch"] = (p["offer_term_months"] - p["desired_term_months"]).abs() / p["desired_term_months"].clip(lower=1)
    p["estimated_dscr"] = p["profit_mean"] / (p["existing_payment"] + p["estimated_payment"]).clip(lower=1)
    checks = pd.DataFrame({
        "purpose": p["offer_purpose"].eq(p["purpose"]) | p["offer_purpose"].eq("any"),
        "amount": p["requested_amount"].between(p["min_amount"], p["max_amount"]),
        "age": p["company_age_months"].ge(p["min_age_months"]),
        "overdue": p["overdue_days"].le(max_overdue_days),
        "cashflow": p["estimated_dscr"].ge(min_estimated_dscr),
        "collateral": ~p["collateral_required"] | p["collateral_coverage"].ge(1.),
    })
    p["eligible"] = checks.all(axis=1)
    p["exclusion_reasons"] = checks.apply(lambda r: ",".join(r.index[~r]), axis=1)
    return p

def input_frame(frame, features, categorical, numeric):
    x = frame[features].copy()
    for c in categorical: x[c] = x[c].fillna("__MISSING__").astype(str)
    x[numeric] = x[numeric].astype(float).replace([np.inf, -np.inf], np.nan)
    return x

class CreditRanker:
    """Load a trusted exported bundle once and reuse it for inference."""
    def __init__(self, bundle_dir, verify=True):
        self.root = Path(bundle_dir).resolve()
        self.manifest = json.loads((self.root / 'bundle_manifest.json').read_text())
        if self.manifest['format_version'] != 1:
            raise ValueError('Unsupported bundle format')
        if verify:
            checksums = json.loads((self.root / 'checksums.json').read_text())
            for relative, expected in checksums.items():
                path = (self.root / relative).resolve()
                if not path.is_relative_to(self.root):
                    raise ValueError('Invalid bundle path')
                if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                    raise ValueError(f'Bundle checksum mismatch: {relative}')
        self.schema = json.loads((self.root / 'feature_schema.json').read_text())
        self.processor = joblib.load(self.root / 'preprocessor.joblib')
        actual = self.processor.get_feature_names_out().tolist()
        if actual != self.schema['encoded_features']:
            raise ValueError('Preprocessor and feature order disagree')
        self.offers = pd.read_csv(self.root / 'offers.csv')
        self.offers['collateral_required'] = self.offers['collateral_required'].astype(str).str.lower().isin(['true','1'])
        self._loaded = {}
        self._load(self.manifest['serving_model'])

    @property
    def available_models(self):
        return list(self.manifest['models'])

    def _load(self, name):
        if name not in self.manifest['models']:
            raise ValueError(f'Unknown model; available: {self.available_models}')
        if name in self._loaded:
            return self._loaded[name]
        spec = self.manifest['models'][name]
        if spec['kind'] == 'catboost':
            from catboost import CatBoostRanker
            models = []
            for filename in spec['files']:
                model = CatBoostRanker()
                model.load_model(str(self.root / filename))
                models.append(model)
            result = ('catboost', models)
        elif spec['kind'] == 'torch':
            checkpoint = torch.load(self.root / spec['file'], map_location='cpu', weights_only=True)
            width = checkpoint['input_dim']
            if width != len(self.schema['encoded_features']):
                raise ValueError('Checkpoint input dimension mismatch')
            if checkpoint['architecture'] == 'mlp':
                model = nn.Sequential(nn.Linear(width,64),nn.ReLU(),nn.Dropout(.1),
                    nn.Linear(64,32),nn.ReLU(),nn.Linear(32,1))
            elif checkpoint['architecture'] == 'tabm':
                from tabm import TabM
                model = TabM.make(n_num_features=width,cat_cardinalities=[],d_out=1,
                                 **checkpoint['tabm_config'])
            else:
                raise ValueError('Unsupported neural architecture')
            model.load_state_dict(checkpoint['state_dict'], strict=True)
            model.eval()
            result = ('torch', model)
        else:
            raise ValueError('Unsupported model kind')
        self._loaded[name] = result
        return result

    @staticmethod
    def _torch_scores(model, tensor):
        output = model(tensor)
        if output.ndim == 3:
            output = output.squeeze(-1)
        return output.mean(dim=1)

    def matrix(self, frame):
        schema = self.schema
        x = input_frame(frame,schema['features'],schema['categorical'],schema['numeric'])
        matrix = self.processor.transform(x).astype('float32')
        if not np.isfinite(matrix).all():
            raise ValueError('Non-finite encoded features')
        return matrix

    def predict_matrix(self, matrix, model_name=None):
        name = model_name or self.manifest['serving_model']
        kind, model = self._load(name)
        if kind == 'catboost':
            scores = np.mean([m.predict(matrix) for m in model],axis=0)
        else:
            with torch.no_grad():
                scores = self._torch_scores(model,torch.as_tensor(matrix,dtype=torch.float32)).numpy()
        scores = np.asarray(scores).reshape(-1)
        if not np.isfinite(scores).all():
            raise ValueError('Non-finite model scores')
        return scores

    def score_candidates(self, frame, model_name=None):
        return self.predict_matrix(self.matrix(frame),model_name)

    def normalize_client(self, payload):
        if not isinstance(payload,dict):
            raise ValueError('client must be a JSON object')
        client = dict(payload)
        missing = [c for c in self.schema['required_client_fields'] if c not in client or client[c] is None]
        if missing:
            raise ValueError(f'Missing client fields: {missing}')
        for c in self.schema['client_numeric_fields']:
            try:
                client[c] = float(client[c])
            except (ValueError,TypeError,OverflowError) as error:
                raise ValueError(f'Numeric field expected: {c}') from error
            if not np.isfinite(client[c]):
                raise ValueError(f'Finite value expected: {c}')
        if client['requested_amount'] <= 0 or client['desired_term_months'] <= 0:
            raise ValueError('Amount and requested term must be positive')
        client['cash_months'] = client['cash_last'] / max(client['revenue_mean'],1)
        client['requested_to_revenue'] = client['requested_amount'] / max(client['revenue_mean'],1)
        for c in self.schema['client_categorical_fields']:
            client[c] = str(client[c])
        client['company_id'] = str(client.get('company_id','request'))
        # Avoid collisions with offer attributes in a cross join.
        allowed = set(self.schema['required_client_fields']) | {'company_id','cash_months','requested_to_revenue'}
        return {k:v for k,v in client.items() if k in allowed}

    def candidates(self,payload):
        client = self.normalize_client(payload)
        rules = self.manifest['availability_rules']
        return make_candidates(pd.DataFrame([client]), self.offers,
            rules['max_overdue_days'], rules['min_dscr'])

    def recommend(self,client,k=3,model_name=None,explain=False):
        if not isinstance(k,int) or isinstance(k,bool) or not 1 <= k <= 50:
            raise ValueError('k must be an integer between 1 and 50')
        name = model_name or self.manifest['serving_model']
        self._load(name)
        candidates = self.candidates(client)
        eligible = candidates[candidates['eligible']].copy()
        result = {'model_name':name,'model_version':self.manifest['model_version'],
            'score_type':'ranking_score','score_is_probability':False,
            'eligible_count':len(eligible),'candidate_count':len(candidates),
            'status':'ok' if len(eligible) else 'no_eligible_offers','recommendations':[]}
        if eligible.empty:
            result['exclusions'] = json.loads(candidates[['offer_id','exclusion_reasons']].to_json(orient='records'))
            return result
        eligible['ranking_score'] = self.score_candidates(eligible,name)
        eligible = eligible.sort_values(['ranking_score','offer_id'],ascending=[False,True])
        columns = ['offer_id','product_type','lender_id','annual_rate','offer_term_months',
            'upfront_fee_rate','estimated_payment','estimated_total_cost_ratio','collateral_required','ranking_score']
        result['recommendations'] = json.loads(eligible.head(k)[columns].to_json(orient='records',double_precision=15))
        if explain:
            result['explanation'] = self.explain(client,model_name=name)
        return result

    def explain(self,client,first_offer_id=None,reference_offer_id=None,model_name=None):
        name = model_name or self.manifest['serving_model']
        kind,model = self._load(name)
        eligible = self.candidates(client)
        eligible = eligible[eligible['eligible']].copy()
        if len(eligible) < 2:
            return {'status':'not_applicable','reason':'Fewer than two eligible offers'}
        eligible['ranking_score'] = self.score_candidates(eligible,name)
        eligible = eligible.sort_values(['ranking_score','offer_id'],ascending=[False,True]).reset_index(drop=True)
        first_offer_id = first_offer_id or eligible.iloc[0]['offer_id']
        if reference_offer_id is None:
            alternatives = eligible[eligible['offer_id'].ne(first_offer_id)]
            if alternatives.empty:
                raise ValueError('No reference offer')
            reference_offer_id = alternatives.iloc[0]['offer_id']
        try:
            first = eligible[eligible['offer_id'].eq(first_offer_id)].iloc[0]
            reference = eligible[eligible['offer_id'].eq(reference_offer_id)].iloc[0]
        except IndexError as error:
            raise ValueError('Both explained offers must be eligible for this client') from error
        compared = pd.DataFrame([first,reference]).reset_index(drop=True)
        matrix = self.matrix(compared)
        scores = self.predict_matrix(matrix,name)
        difference = float(scores[0]-scores[1])
        if kind == 'catboost':
            from catboost import Pool
            shap = np.mean([m.get_feature_importance(Pool(matrix),type='ShapValues') for m in model],axis=0)
            attr = shap[0,:-1]-shap[1,:-1]
            base_difference = float(shap[0,-1]-shap[1,-1])
            method = 'tree_shap_difference'
            steps = None
        else:
            model.eval()
            base = torch.as_tensor(matrix[1],dtype=torch.float32)
            delta = torch.as_tensor(matrix[0]-matrix[1],dtype=torch.float32)
            base_difference = 0.
            for steps in [64,128,256,512,1024]:
                with torch.enable_grad():
                    alpha = torch.linspace(0,1,steps+1)[:,None]
                    points = (base[None,:]+alpha*delta[None,:]).requires_grad_(True)
                    value = self._torch_scores(model,points)
                    gradient = torch.autograd.grad(value.sum(),points)[0]
                    average = ((gradient[:-1]+gradient[1:])*.5).mean(dim=0)
                    attr = (delta*average).detach().numpy()
                residual = difference-float(attr.sum())
                if abs(residual) <= max(.001,.01*abs(difference)):
                    break
            method = 'integrated_gradients_offer_difference'
        encoded_map = self.schema['encoded_to_raw']
        grouped = {f:0. for f in self.schema['features']}
        for feature,value in zip(encoded_map,attr):
            grouped[feature] += float(value)
        attributions = []
        for feature,contribution in sorted(grouped.items(),key=lambda x:abs(x[1]),reverse=True):
            attributions.append({'feature':feature,'label':self.schema['labels'][feature],
                'contribution':contribution,'first_value':_plain(first[feature]),
                'reference_value':_plain(reference[feature])})
        residual = difference-base_difference-sum(grouped.values())
        return {'status':'ok','model_name':name,'method':method,
            'target':'score(first_offer)-score(reference_offer)',
            'first_offer_id':first_offer_id,'reference_offer_id':reference_offer_id,
            'first_score':float(scores[0]),'reference_score':float(scores[1]),
            'score_difference':difference,'base_difference':base_difference,
            'integration_steps':steps,'completeness_residual':float(residual),
            'completeness_ok':abs(residual)<=max(.001,.01*abs(difference)),
            'attributions':attributions,
            'interpretation':'Positive contribution supports first offer relative to reference. Model attribution is not a causal effect.',
            'scope':'Scorer on eligible offers; eligibility rules are reported separately.'}

    def feature_importance(self,model_name=None):
        name = model_name or self.manifest['serving_model']
        path = self.root/'explanations'/'global_importance.json'
        if not path.exists():
            return {'status':'not_exported','model_name':name}
        data = json.loads(path.read_text())
        if name not in data['models']:
            raise ValueError('No exported importance for this model')
        return data['models'][name]

    def _aux_module(self,filename):
        import importlib.util
        import uuid
        if not hasattr(self,'_aux_cache'):self._aux_cache={}
        if filename not in self._aux_cache:
            spec=importlib.util.spec_from_file_location('credit_aux_'+uuid.uuid4().hex,self.root/filename)
            module=importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            self._aux_cache[filename]=module
        return self._aux_cache[filename]

    def bert_history_scores(self,history):
        sequence=self.manifest.get('sequence_model')
        if sequence is None:
            return None,dict(known_count=0,unknown_count=len(history or []),used_count=0,truncated_count=0)
        module=self._aux_module('bert4rec.py')
        if not hasattr(self,'_bert_model'):
            checkpoint=torch.load(self.root/sequence['file'],map_location='cpu',weights_only=True)
            model=module.BERT4Rec(**checkpoint['config'])
            model.load_state_dict(checkpoint['state_dict'],strict=True);model.eval()
            vocabulary=json.loads((self.root/sequence['vocabulary']).read_text())
            if checkpoint['config']['n_items']!=len(vocabulary['item_to_id']):
                raise ValueError('Sequence checkpoint vocabulary size mismatch')
            self._bert_model=model
            self._item_to_id=vocabulary['item_to_id']
        return module.score_history(self._bert_model,history,self._item_to_id)

    def _cascade_cheap(self,matrix):
        if not hasattr(self,'_cheap_model'):
            spec=self.manifest['cascade']['cheap_model']
            self._cheap_model=json.loads((self.root/spec).read_text())
        coefficients=np.asarray(self._cheap_model['coef'],dtype=float)
        if coefficients.shape!=(matrix.shape[1],):raise ValueError('Cheap model dimension mismatch')
        return matrix@coefficients+float(self._cheap_model['intercept'])

    def recommend_cascade(self,client,history=None,k=3,explain=False,mode='auto'):
        import time
        if mode not in ['auto','cheap','deep','strong']:raise ValueError('Invalid cascade mode')
        if not isinstance(k,int) or isinstance(k,bool) or not 1<=k<=50:raise ValueError('k must be 1..50')
        if history is None:history=[]
        if not isinstance(history,(list,tuple)) or any(not isinstance(x,str) for x in history):
            raise ValueError('history must be a chronological list of offer_id strings')
        if len(history)>10000:raise ValueError('history is too long')
        cascade=self.manifest.get('cascade')
        if cascade is None:raise ValueError('No exported cascade policy')
        start=time.perf_counter()
        candidates=self.candidates(client)
        eligible=candidates[candidates['eligible']].copy().reset_index(drop=True)
        if eligible.empty:
            return {'status':'no_eligible_offers','model_version':self.manifest['model_version'],
                'score_is_probability':False,'model_name':'cascade','recommendations':[],
                'eligible_count':0,'trace':{'path':'no_eligible_offers','used_bert':False},
                'exclusions':json.loads(candidates[['offer_id','exclusion_reasons']].to_json(orient='records'))}
        stage_start=time.perf_counter()
        matrix=self.matrix(eligible)
        cheap=self._cascade_cheap(matrix)
        cheap_ms=(time.perf_counter()-stage_start)*1000
        logic=self._aux_module('cascade_logic.py')
        strong_name=cascade['strong_model']
        def strong_predict(frame):
            return self.score_candidates(frame,strong_name)
        routed=logic.route_candidates(eligible,cheap,strong_predict,self.bert_history_scores,
            history,cascade['policy'],k=k,mode=mode)
        rows=eligible.iloc[routed['order']].copy()
        rows['ranking_score']=routed['scores']
        columns=['offer_id','product_type','lender_id','annual_rate','offer_term_months',
            'upfront_fee_rate','estimated_payment','estimated_total_cost_ratio','collateral_required','ranking_score']
        trace={key:value for key,value in routed.items() if key not in ['order','scores']}
        trace['candidate_offer_ids']=eligible.iloc[routed['candidate_indices']]['offer_id'].tolist()
        trace['timings_ms']['feature_and_cheap_ms']=cheap_ms
        trace['timings_ms']['total_ms']=(time.perf_counter()-start)*1000
        trace['strong_model']=strong_name
        trace['margin_is_probability']=False
        result={'status':'ok','model_name':'cascade','model_version':self.manifest['model_version'],
            'score_type':'ranking_score','score_is_probability':False,
            'eligible_count':len(eligible),'candidate_count':len(candidates),
            'recommendations':json.loads(rows.head(k)[columns].to_json(orient='records',double_precision=15)),
            'trace':trace}
        if explain and len(rows)>=2:
            if routed['fast_path']:
                top=rows.iloc[:2]
                z=self.matrix(top)
                attr=(z[0]-z[1])*np.asarray(self._cheap_model['coef'],dtype=float)
                grouped={feature:0. for feature in self.schema['features']}
                for feature,value in zip(self.schema['encoded_to_raw'],attr):grouped[feature]+=float(value)
                gap=float(top.iloc[0]['ranking_score']-top.iloc[1]['ranking_score'])
                result['explanation']={'status':'ok','method':'linear_score_difference',
                    'target':'score(first_offer)-score(reference_offer)',
                    'first_offer_id':top.iloc[0]['offer_id'],'reference_offer_id':top.iloc[1]['offer_id'],
                    'score_difference':gap,'completeness_residual':gap-sum(grouped.values()),
                    'completeness_ok':abs(gap-sum(grouped.values()))<=1e-5,
                    'attributions':[dict(feature=f,label=self.schema['labels'][f],contribution=v)
                        for f,v in sorted(grouped.items(),key=lambda x:abs(x[1]),reverse=True)],
                    'scope':'Cheap linear scorer only; history retrieval was not used.'}
            else:
                result['explanation']=self.explain(client,rows.iloc[0]['offer_id'],rows.iloc[1]['offer_id'],strong_name)
                result['explanation']['scope']='Final scorer conditional on the selected candidates. Retrieval decisions are in trace.'
        elif explain:
            result['explanation']={'status':'not_applicable','reason':'Fewer than two ranked offers'}
        return result

    def explain_history(self,history,target_offer_id,limit=8):
        if not isinstance(limit,int) or not 1<=limit<=50:raise ValueError('limit must be 1..50')
        full,info=self.bert_history_scores(history)
        if full is None:return {'status':'not_applicable','reason':'No known historical items','history':info}
        if target_offer_id not in full:raise ValueError('Unknown target offer_id')
        prefix=list(history)[-min(limit,len(history)):]
        start=len(history)-len(prefix)
        changes=[]
        for local_index,item in enumerate(prefix):
            index=start+local_index
            reduced=list(history[:index])+list(history[index+1:])
            scores,_=self.bert_history_scores(reduced)
            if scores is None:
                changes.append(dict(history_index=index,offer_id=item,logit_change=None))
            else:
                changes.append(dict(history_index=index,offer_id=item,
                    logit_change=float(full[target_offer_id]-scores[target_offer_id])))
        return {'status':'ok','method':'history_item_deletion_sensitivity','target_offer_id':target_offer_id,
            'baseline_logit':float(full[target_offer_id]),'history':info,'events':changes,
            'additive':False,'interpretation':'Deleting one event can shift positions. Changes are not additive or causal.'}


def _plain(value):
    if isinstance(value,np.generic):
        return value.item()
    return value
