import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch

def rank(client,fixture,**extra):
    headers,profile,_,products=fixture
    payload={'profile_id':profile['id'],'products':[p['id'] for p in products],**extra}
    return client.post('/rank/products',headers=headers,json=payload)

def test_bundle_integrity_and_health(client):
    response=client.get('/health')
    assert response.status_code==200 and response.json()['model_version'].startswith('sme-ranking-')
    root=Path(__file__).resolve().parents[1]/'ml_bundle'
    import hashlib
    for name,checksum in json.loads((root/'checksums.json').read_text()).items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==checksum

def test_authentication_is_required(client):
    assert client.post('/rank/products',json={'profile_id':1,'products':[1]}).status_code==401
    assert client.post('/profile/',json={}).status_code in (401,422)

def test_real_cascade_and_explanation(client,funded):
    response=rank(client,funded)
    assert response.status_code==200,response.text
    result=response.json()['result']
    assert result['model_name']=='cascade' and result['recommendations']
    assert result['model_version']==client.get('/health').json()['model_version']
    assert result['score_is_probability'] is False
    assert result['input_context']['financial_months']==6
    assert all('product_id' in x for x in result['recommendations'])
    assert result['explanation']['completeness_ok']
    assert not all(x['ranking_score']==.5 for x in result['recommendations'])
    stored=client.get('/rank/'+str(response.json()['ranking_id']),headers=funded[0])
    assert stored.status_code==200 and stored.json()['result']['recommendations']==result['recommendations']

def test_events_feed_bert_only_after_explicit_selection(client,funded):
    headers,profile,_,_=funded
    cold=rank(client,funded,mode='deep');assert cold.status_code==200,cold.text
    assert cold.json()['result']['trace']['path']=='cold_start_strong'
    product=cold.json()['result']['recommendations'][0]['product_id']
    event={'profile_id':profile['id'],'payload':{'product_id':product}}
    assert client.post('/events/',headers=headers,json={**event,'event_type':'product_view'}).status_code==200
    viewed=rank(client,funded,mode='deep')
    assert viewed.json()['result']['history_event_count']==0
    assert client.post('/events/',headers=headers,json={**event,'event_type':'offer_selected'}).status_code==200
    deep=rank(client,funded,mode='deep');assert deep.status_code==200,deep.text
    assert deep.json()['result']['history_event_count']==1
    assert deep.json()['result']['trace']['used_bert']
    history=client.post('/ml/explain-history',headers=headers,json={'profile_id':profile['id'],'product_id':product})
    assert history.status_code==200 and history.json()['method']=='history_item_deletion_sensitivity'

def test_requested_subset_is_applied_before_ranking(client,funded):
    first=rank(client,funded).json()['result']['recommendations'][0]['product_id']
    result=rank(client,funded,products=[first]).json()['result']
    assert result['candidate_count']==1
    assert [r['product_id'] for r in result['recommendations']]==[first]

def test_parallel_subsets_do_not_mutate_shared_catalog(client,funded):
    rows=rank(client,funded).json()['result']['recommendations']
    ids=[r['product_id'] for r in rows[:2]]
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(lambda product_id:rank(client,funded,products=[product_id]).json()['result'],ids))
    assert [[r['product_id'] for r in response['recommendations']] for response in results]==[[i] for i in ids]
    assert client.get('/products/').status_code==200 and len(client.get('/products/').json())==33

def test_ownership_across_all_profile_routes(client,funded,account):
    import uuid
    other_response=client.post('/auth/register',json={'email':'other-'+uuid.uuid4().hex[:10]+'@example.com','password':'Testing123!'})
    assert other_response.status_code==200
    other={'Authorization':'Bearer '+other_response.json()['access_token']};profile=funded[1]
    requests=[('get',f"/profile/{profile['id']}",None),('get',f"/metrics/{profile['id']}",None),
        ('get',f"/dashboard/{profile['id']}",None),('post','/rank/products',{'profile_id':profile['id'],'products':[1]}),
        ('post','/events/',{'profile_id':profile['id'],'event_type':'dashboard_view'}),
        ('post',f"/metrics/{profile['id']}",{'metrics':funded[2]})]
    for method,url,payload in requests:
        response=client.request(method,url,headers=other,**({'json':payload} if payload else {}))
        assert response.status_code==404,(url,response.text)

def test_metrics_upsert_and_future_rejection(client,funded):
    headers,profile,metrics,_=funded
    assert client.post(f"/metrics/{profile['id']}",headers=headers,json={'metrics':metrics}).status_code==200
    assert len(client.get(f"/metrics/{profile['id']}",headers=headers).json())==6
    future={**metrics[0],'period':'2099-01'}
    assert client.post(f"/metrics/{profile['id']}",headers=headers,json={'metrics':[future]}).status_code==422

def test_missing_finances_returns_actionable_error(client,profile):
    headers,record=profile
    response=client.post('/rank/products',headers=headers,json={'profile_id':record['id'],'products':[1]})
    assert response.status_code==422 and 'завершённый месяц' in response.json()['detail']

def test_empty_result_and_unknown_products(client,funded):
    assert rank(client,funded,products=[999999]).status_code==422
    headers,profile,_,_=funded
    payload={k:v for k,v in profile.items() if k in ['industry','employees','goals','credit_context','revenue_band']}
    payload['credit_context']={**payload['credit_context'],'requested_amount':1e15}
    assert client.post('/profile/',headers=headers,json=payload).status_code==200
    response=rank(client,funded);assert response.status_code==200,response.text
    assert response.json()['result']['status']=='no_eligible_offers'
    assert response.json()['result']['recommendations']==[]

def test_model_errors_are_not_fake_scores(client,funded):
    engine=client.app.state.ranking_engine
    with patch.object(engine,'rank',side_effect=RuntimeError('test outage')):
        response=rank(client,funded)
    assert response.status_code==503
    assert 'заглушкой' in response.json()['detail']

def test_interpretability_endpoints(client,account):
    headers=account[0]
    status=client.get('/ml/status',headers=headers)
    assert status.status_code==200 and status.json()['sequence_model']['kind']=='BERT4Rec'
    assert client.get('/ml/features',headers=headers).status_code==200
    importance=client.get('/ml/feature-importance',headers=headers)
    assert importance.status_code==200 and len(importance.json()['features'])==28

def test_exported_weights_reproduce_uploaded_examples(client):
    import numpy as np
    engine=client.app.state.ranking_engine
    root=Path(__file__).resolve().parents[1]/'ml_bundle'
    request=json.loads((root/'example_request.json').read_text())
    expected=json.loads((root/'example_response.json').read_text())
    actual=engine.base.recommend(**request)
    assert [r['offer_id'] for r in actual['recommendations']]==[r['offer_id'] for r in expected['recommendations']]
    assert np.allclose([r['ranking_score'] for r in actual['recommendations']], [r['ranking_score'] for r in expected['recommendations']],atol=1e-5,rtol=1e-5)
    assert actual['explanation']['method']=='grouped_permutation_shapley_reference_difference'
    assert actual['explanation']['completeness_ok']
    request=json.loads((root/'example_cascade_request.json').read_text())
    expected=json.loads((root/'example_cascade_response.json').read_text())
    actual=engine.base.recommend_cascade(**request)
    assert actual['trace']['path']==expected['trace']['path']
    assert [r['offer_id'] for r in actual['recommendations']]==[r['offer_id'] for r in expected['recommendations']]
    assert np.allclose([r['ranking_score'] for r in actual['recommendations']], [r['ranking_score'] for r in expected['recommendations']],atol=1e-5,rtol=1e-5)

def test_registered_and_legacy_accounts_can_login(client,account):
    headers,email=account
    assert client.post('/auth/login',json={'email':email,'password':'Testing123!'}).status_code==200
    assert client.post('/auth/login',json={'email':email,'password':'wrong'}).status_code==401
    from app.core.database import SessionLocal
    from app.models import User
    import hashlib,uuid
    legacy='legacy-'+uuid.uuid4().hex[:8]+'@example.com'
    with SessionLocal() as db:
        db.add(User(email=legacy,password_hash=hashlib.sha256(b'OldPass123!').hexdigest(),role='user'));db.commit()
    assert client.post('/auth/login',json={'email':legacy,'password':'OldPass123!'}).status_code==200
