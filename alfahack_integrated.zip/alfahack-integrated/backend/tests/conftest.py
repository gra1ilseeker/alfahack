import os
from pathlib import Path
import pytest
from fastapi.testclient import TestClient

@pytest.fixture(scope='session')
def client(tmp_path_factory):
    path=tmp_path_factory.mktemp('cabinet')/'test.db'
    os.environ['DATABASE_URL']='sqlite:///'+str(path)
    from app.main import app
    with TestClient(app) as test_client:yield test_client

@pytest.fixture
def account(client):
    import uuid
    email='test-'+uuid.uuid4().hex[:10]+'@example.com'
    response=client.post('/auth/register',json={'email':email,'password':'Testing123!'})
    assert response.status_code==200,response.text
    return {'Authorization':'Bearer '+response.json()['access_token']},email

@pytest.fixture
def profile(client,account):
    headers,email=account
    response=client.post('/profile/',headers=headers,json={
        'user_email':email,'industry':'retail','employees':11,'goals':'Кассовый разрыв',
        'credit_context':{'requested_amount':3314185.89,'desired_term_months':24,
            'company_age_months':125,'region':'ural','legal_form':'IE','purpose':'cash_gap',
            'overdue_days':0,'collateral_coverage':1.745627,'cash_balance':1626629.75,
            'debt_balance':2244877.09,'monthly_debt_payment':93536.55}})
    assert response.status_code==200,response.text
    return headers,response.json()

@pytest.fixture
def funded(client,profile):
    headers,profile=profile
    metrics=[{'period':f'2026-{month:02d}','revenue':2724811.82,'expenses':2050744.27,
        'cash_flow':674067.55,'online_share':.35} for month in range(4,10)]
    response=client.post(f"/metrics/{profile['id']}",headers=headers,json={'metrics':metrics})
    assert response.status_code==200,response.text
    products=client.get('/products/').json()
    assert len(products)==33
    return headers,profile,metrics,products
